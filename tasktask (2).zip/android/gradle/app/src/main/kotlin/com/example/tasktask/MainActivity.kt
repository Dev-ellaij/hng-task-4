package com.example.tasktask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
